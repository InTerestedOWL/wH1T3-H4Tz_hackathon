package wH1T3_h4Tz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import wH1T3_h4Tz.BlurFilter.cornerPolicy;



public abstract class ImageProcessor {
	
	
	
	public static BlurFilter gausianBlur(BufferedImage image, int radius, double pitch, cornerPolicy cornerPolicy, boolean[][] mask) {
		
		return new BlurFilter(image, radius, pitch, true, cornerPolicy, mask);
	}
	
	
	
	public static BufferedImage convertToGrayScale(BufferedImage image) {
		
		if(image.getType() == BufferedImage.TYPE_BYTE_GRAY) return image;
		
		BufferedImage grayScale = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		Graphics g = grayScale.getGraphics();
		g.drawImage(image, 0, 0, null);
		g.dispose();
		
		return grayScale;
	}
	

	
	public static BufferedImage cannyEdgeDetection(BufferedImage image, int lowerThreshold, int upperThreshold, boolean[][] mask) {
		
		return new CannyEdgeDetector(image, lowerThreshold, upperThreshold, mask).detectEdges();
	}
	
	
	
	public static  BufferedImage rescaleImage(BufferedImage image, int width, int height, boolean smooth) {
		
		if(image == null) return null;
		
		BufferedImage resized = new BufferedImage((image.getWidth() / image.getWidth() * width), 
				(image.getHeight() / image.getHeight() * height), image.getType());
		
		Graphics2D g = resized.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, smooth ? 
				RenderingHints.VALUE_INTERPOLATION_BICUBIC : RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		g.drawImage(image, 0,0, resized.getWidth(), resized.getHeight(), 0, 0, image.getWidth(), image.getHeight(), null);
		g.dispose();
		
		return resized;
    }
	
	
	
	public static boolean[][] combineEdges(boolean[][] a, boolean[][] b,
	        boolean or) {

		boolean[][] c = new boolean[a.length][a[0].length];

		for (int x = 0; x < a.length; x++) {

			for (int y = 0; y < a[0].length; y++) {

				c[x][y] = or ? a[x][y] || b[x][y] : a[x][y] && b[x][y];
			}
		}

		return c;
	}

	
	
	public static boolean[][] convertToBooleanArray(BufferedImage image) {

		boolean[][] edges = new boolean[image.getWidth()][image.getHeight()];
		for (int x = 0; x < image.getWidth(); x++) {

			for (int y = 0; y < image.getHeight(); y++) {

				if (image.getRGB(x, y) == Color.WHITE.getRGB())
					edges[x][y] = true;
			}
		}

		return edges;
	}

	
	
	public static boolean[][] filterForEdges(boolean[][] edges,
	        boolean[][] mask, int threshold, boolean horizontal) {

		boolean[][] result = new boolean[edges.length][edges[0].length];
		boolean[][] longify = new boolean[edges.length][edges[0].length];

		for (int x = 0; x < edges.length; x++) {

			for (int y = 0; y < edges[0].length; y++) {

				result[x][y] = edges[x][y];
			}
		}

		for (int x = 0; x < (horizontal ? result[0].length
		        : result.length); x++) {

			int counter = 0;
			for (int y = 0; y < (horizontal ? result.length
			        : result[0].length); y++) {

				if (result[horizontal ? y : x][horizontal ? x : y] == true) {

					counter++;
					continue;
				}

				if (counter > 0 && counter < threshold) {

					for (int deletionIndex = y
					        - counter; deletionIndex < y; deletionIndex++) {

						result[horizontal ? deletionIndex : x][horizontal ? x
						        : deletionIndex] = false;
					}
				} else if (counter > 0 && counter >= threshold) {

					int start = y;
					int end = y;
					
					while(!mask[horizontal ? start : x][horizontal ? x : start] && start > 0) {
						start--;
					}
					while(!mask[horizontal ? end : x][horizontal ? x : end] && end < (horizontal ? result.length - 1
					        : result[0].length - 1)) {
						end++;
					}

					for (int longifyIndex = start; longifyIndex < end; longifyIndex++) {

						longify[horizontal ? longifyIndex : x][horizontal ? x : longifyIndex] = true;
					}
				}
				counter = 0;
			}
		}

		return combineEdges(result, longify, true);
	}

	
	
	public static BufferedImage convertArrayToImage(boolean[][] input) {

		BufferedImage image = new BufferedImage(input.length, input[0].length,
		        BufferedImage.TYPE_BYTE_GRAY);
		Graphics g = image.createGraphics();

		for (int x = 0; x < input.length; x++) {

			for (int y = 0; y < input[0].length; y++) {

				int color = input[x][y] == true ? 255 : 0;
				g.setColor(new Color(color, color, color));
				g.drawLine(x, y, x, y);
			}
		}

		g.dispose();

		return image;
	}

	
	
	public static boolean[][] createMask(BufferedImage mask) {

		boolean[][] result = new boolean[mask.getWidth()][mask.getHeight()];

		for (int x = 0; x < mask.getWidth(); x++) {

			for (int y = 0; y < mask.getHeight(); y++) {

				if (mask.getRGB(x, y) >>24 == 0x00)
					result[x][y] = true;
			}
		}

		return result;
	}
}
