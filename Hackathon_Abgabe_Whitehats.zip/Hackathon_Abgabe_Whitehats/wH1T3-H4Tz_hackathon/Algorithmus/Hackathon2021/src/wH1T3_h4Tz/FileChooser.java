package wH1T3_h4Tz;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

public class FileChooser {

	public static String getOpenFilePath(JFrame frame) {

		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Open image");

		chooser.resetChoosableFileFilters();
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setSelectedFile(null);

		chooser.addChoosableFileFilter(new FileNameExtensionFilter(
		        "Image-Files", "png", "gif", "jpg", "bmp", "jpeg"));

		try {
			
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			SwingUtilities.updateComponentTreeUI(chooser);
		} catch (Exception e) {}

		if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
			
			if (chooser.getSelectedFile() != null) {
				
				return chooser.getSelectedFile().getPath();
			} else {
				
				return null;
			}
		} else {
			
			return null;
		}
	}

	
	
	public static String getSaveFilePath(JFrame frame) {

		boolean overwrite = true;
		String filepath = "";
		String newfilepath = "";

		JFileChooser filechooser = new JFileChooser();
		filechooser.setDialogTitle("Export image");

		filechooser.setSelectedFile(null);
		filechooser.resetChoosableFileFilters();
		filechooser.setAcceptAllFileFilterUsed(false);

		filechooser.addChoosableFileFilter(
		        new FileNameExtensionFilter("Image", "png"));

		if (filechooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {

			File filenew = filechooser.getSelectedFile();

			if (filenew != null && filenew.exists()) {
				
				int wanttooverwrite = JOptionPane.showConfirmDialog(frame,
				        "A file with this name already exists.\n\nDo you want to overwrite it?",
				        "Warning!", JOptionPane.YES_NO_OPTION);
				if (wanttooverwrite == JOptionPane.YES_OPTION) {
					
					overwrite = true;
				} else {
					
					overwrite = false;
				}
			}

			if (filenew != null && overwrite == true) {
				
				filepath = filenew.toString();
				int index = filepath.lastIndexOf(".");
				if (index > 0) {
					
					filepath = filepath.substring(0, index);
				}
				newfilepath = filepath + ".png";
			} else {

				return null;
			}
		} else {

			return null;
		}

		return newfilepath;
	}
}