package wH1T3_h4Tz;

import java.awt.image.BufferedImage;

public interface IEdgeDetector {

	public abstract BufferedImage detectEdges();
}
