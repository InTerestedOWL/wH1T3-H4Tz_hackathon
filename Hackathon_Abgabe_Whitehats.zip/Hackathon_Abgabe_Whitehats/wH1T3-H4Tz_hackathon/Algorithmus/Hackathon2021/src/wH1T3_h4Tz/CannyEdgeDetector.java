package wH1T3_h4Tz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;



public class CannyEdgeDetector implements IEdgeDetector {

	private static int[] edgesX = new int[] {
			-1, 0, 1, -2, 0, 2, -1, 0, 1
	};
	
	private static int[] edgesY = new int[] {
			-1, -2, -1, 0, 0, 0, 1, 2, 1
	};

	
	
	private static int[] degreesWWEE = new int[] {
			1, 1, 1, 0, 0, 0, 1, 1, 1
	};

	private static int[] degreesNNSS = new int[] {
			1, 0, 1, 1, 0, 1, 1, 0, 1
	};

	private static int[] degreesNWSE = new int[] {
			0, 0, 1, 0, 0, 0, 1, 0, 0
	};

	private static int[] degreesSWNE = new int[] {
			1, 0, 0, 0, 0, 0, 0, 0, 1
	};
	
	
	
	private BufferedImage image;
	
	private double[][] degrees; 
	
	private int lowerThreshold;
	private int upperThreshold;
	private boolean[][] mask;
	
	
	
	public CannyEdgeDetector(BufferedImage image, int lowerThreshold, int upperThreshold, boolean[][] mask) {
		this.image = image; 
		this.lowerThreshold = lowerThreshold;
		this.upperThreshold = upperThreshold;
		this.mask = mask; 
		
	}
	
	
	
	@Override
	public BufferedImage detectEdges() {
	
		return this.cannyEdgeCrisping(
				this.blurryEdgeDetection()
		, degrees);
	}
	
	
	
	public BufferedImage blurryEdgeDetection() {
		BufferedImage edges = new BufferedImage(this.image.getWidth(), 
				this.image.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		
		Graphics g = edges.createGraphics();
		
		degrees = new double[image.getWidth()][image.getHeight()];
		
		for(int xP = 1; xP < image.getWidth() - 1; xP++) {
			for(int yP = 1; yP < image.getHeight() - 1; yP++) {

				if(mask[xP][yP]) {
					
					g.setColor(Color.BLACK);
					g.drawLine(xP, yP, xP, yP);
					
					continue;
				}
				
				int arrayPos = 0;
				int xValue = 0;
				int yValue = 0;
				for(int xTemp = xP - 1; xTemp <= xP + 1; xTemp++) {
					
					for(int yTemp = yP - 1; yTemp <= yP + 1; yTemp ++) {
						
						int rgb = new Color(image.getRGB(xTemp, yTemp)).getGreen();
						
						xValue = xValue + (rgb * edgesX[arrayPos]);
						yValue = yValue + (rgb * edgesY[arrayPos]);

						arrayPos++;
					}
				}
				
				int value = (int)(Math.sqrt(Math.pow(xValue, 2) + Math.pow(yValue, 2)));
				try {
					degrees[xP][yP] = Math.atan((double)(xValue / yValue));
				} catch(ArithmeticException e) {
					degrees[xP][yP] = 0;
				}
				
				if(value > 255) value = 255;
				if(value < 0) value = 0;
				
				g.setColor(new Color(value, value, value));
				g.drawLine(xP, yP, xP, yP);			
			}
		}
		g.dispose();
		
		return edges;
	}
	
		
	
	private BufferedImage cannyEdgeThreshold(BufferedImage image) {
		
		BufferedImage importantEdges = new BufferedImage(image.getWidth(), 
				image.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		
		Graphics g = importantEdges.createGraphics();
		
		for(int xP = 1; xP < image.getWidth(); xP++) {
			
			for(int yP = 1; yP < image.getHeight(); yP++) {
				
				if(mask[xP][yP])
					continue;
				
				
				int value = new Color(image.getRGB(xP, yP)).getGreen();
				
				if(value >= this.upperThreshold) {
					value = 255;
				} else if(value < this.lowerThreshold) {
					value = 0;
				} else if(value >= this.lowerThreshold && value < this.upperThreshold) {
					
					boolean important = false;
					for(int xTemp = xP - 1; xTemp <= xP + 1; xTemp++) {
						for(int yTemp = yP - 1; yTemp <= yP + 1; yTemp++) {
							
							int temp = new Color(image.getRGB(xTemp, yTemp)).getGreen();
							if(temp >= this.upperThreshold) important = true;
						}
					}
					
					if(important) value = 255;
					else value = 0;
				}
				
				g.setColor(new Color(value, value, value));
				g.drawLine(xP, yP, xP, yP);
			}
		}
		
		g.dispose();
		
		return importantEdges;
	}
	
	
	
	private BufferedImage cannyEdgeCrisping(BufferedImage image, double[][] degrees) {

		Graphics g = image.createGraphics();
		
		for(int xP = 1; xP < image.getWidth() - 1; xP++) {
			
			for(int yP = 1; yP < image.getHeight() - 1; yP++) {
				
				if(mask[xP][yP])
					continue;
				
				int value = new Color(image.getRGB(xP, yP)).getGreen();
				int max = 0;
				
				int[] mask = getDegreeArray(degrees[xP][yP]);
				
				int arrayPos = 0;
					
				for(int xTemp = xP - 1; xTemp <= xP + 1; xTemp++) {
					
					for(int yTemp = yP - 1; yTemp <= yP + 1; yTemp++) {
						
						int temp = new Color(image.getRGB(xTemp, yTemp)).getGreen();
						if(temp > max && mask[arrayPos] == 1) max = temp;
							
						arrayPos++;
					}
				}
					
				if(max >= value) value = 0;
				g.setColor(new Color(value, value, value));
				g.drawLine(xP, yP, xP, yP);			
			} 
		}
		g.dispose();
		
		return cannyEdgeThreshold(image);
	}
	
	
	
	private static int[] getDegreeArray(double atan) {
		if((atan >= - 0.22 && atan < 0.23) || (atan > 1.57 || atan < -1.57)) {
			
			return degreesWWEE;
		} else if((atan >= 0.67 && atan < 1.12) || (atan <= -0.67 && atan > -1.12)) {
			
			return degreesNNSS;
		} else if((atan >= 0.23 && atan < 0.67) || (atan >= -1.57 && atan <= -1.12)) {
			
			return degreesNWSE;
		} else {
			
			return degreesSWNE;
		}
	}

	
	
	public double[][] getDegrees() {
		return degrees;
	}
}