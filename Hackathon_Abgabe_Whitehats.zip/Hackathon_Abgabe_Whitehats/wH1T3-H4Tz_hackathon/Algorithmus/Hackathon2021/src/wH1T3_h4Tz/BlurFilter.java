package wH1T3_h4Tz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class BlurFilter {
	
	public enum cornerPolicy {ignore, weight};
	
	private BufferedImage sourceImage;
	
	private cornerPolicy corner;
	
	private int radius;
	private double pitch;
	
	private boolean descent;
	
	private int[][] mask;
	private int maskSum;
	
	private boolean[][] cutMask;
	
	public BlurFilter(BufferedImage image, int radius, double pitch, 
			boolean descent, cornerPolicy corner, boolean[][] mask) {
		
		this.sourceImage = image;
		this.corner = corner;
		this.pitch = pitch;
		this.radius = radius;
		this.descent = descent;
		this.cutMask = mask;
		
		this.createMask();
	}
	
	
	
	public BufferedImage blur() {
		
		BufferedImage image = new BufferedImage(this.sourceImage.getWidth(), 
				this.sourceImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		
		Graphics gra = image.getGraphics();
		
		int offset = 0;
		if(this.corner == cornerPolicy.ignore) {
			
			offset = radius;
		}
		
		for(int x = offset; x < this.sourceImage.getWidth() - offset; x++) {
			
			for(int y = offset; y < this.sourceImage.getHeight() - offset; y++) {
				
				if(cutMask[x][y])
					continue;
				
				int g = 0;
				
				for(int innerX = x - this.radius; innerX < x + this.radius; innerX++) {
					for(int innerY = y - this.radius; innerY < y + this.radius; innerY++) {
						
						int xValue = this.getValueInBounds(innerX, offset, this.sourceImage.getWidth() - 1 - offset);
						int yValue = this.getValueInBounds(innerY, offset, this.sourceImage.getHeight() - 1 - offset);
						
						Color spot = new Color(this.sourceImage.getRGB(xValue, yValue));
						
						g += (spot.getGreen() * this.mask[innerX - x + radius][innerY - y + radius]);
												
					}
				}
				
				g = g / maskSum;
				
				gra.setColor(new Color(g, g, g));
				gra.drawLine(x, y, x, y);
				
			}
		}
		gra.dispose();
		
		return image;
	}
	

	
	private int getValueInBounds(int value, int lowerBound, int upperBound) {
		
		if(value < lowerBound) value = lowerBound;
		if(value > upperBound) value = upperBound;
		
		return value;
	}
	
	
	
	private void createMask() {
		
		this.maskSum = 0;
		
		this.mask = new int[this.radius * 2][this.radius * 2];
		
		for(int x = 0; x < this.radius * 2; x++) {
			for(int y = 0; y < this.radius * 2; y++) {
				
				int value = 0;
				
				if(!this.descent) value = (int)Math.round(1 * this.pitch);
				
				else value = this.calculateDescent(x - radius, y - radius);

				this.mask[x][y] = value;
				this.maskSum += value;
			}
		}
	}

	
	
	private int calculateDescent(int x, int y) {
		
		double sigma = 1 / pitch;
		
		return (int)Math.round(100 * (1 / (Math.sqrt(2 * Math.PI * Math.pow(sigma, 2))) ) * 
				Math.pow(Math.E, -( (Math.pow(x, 2) + Math.pow(y, 2)) / (2 * Math.pow(sigma, 2)) ))); 
	}
	
	
	
	public BufferedImage getSourceImage() {
		
		return this.sourceImage;
	}
}
