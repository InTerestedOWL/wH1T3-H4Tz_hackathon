package wH1T3_h4Tz;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;



import wH1T3_h4Tz.BlurFilter.cornerPolicy;



/**
 * Hackathon prototype of a parking lot surveillance system.
 * In production mode, it would get its image-data from a camera
 * and would perform a load-analysis every few seconds.
 * The result would be sent as a simple bit-array, each bit representing
 * the state of a single parking spot (1 = occupied, 0 = vacant)
 * 
 * @author wH1T3#h4Tz
 *
 */
public class ParkingSpaceSurveillance {
	
	private int width;
	private int height;
	
	
	public static void main(String[] args) {

		new ParkingSpaceSurveillance(640, 480);
	}
	
	
	
	public ParkingSpaceSurveillance(int outputWidth, int outputHeight) {
		
		this.width = outputWidth;
		this.height = outputHeight;
		
		this.runSurveillanceFrameanalysis();
	}
	
	
	
	/*
	 * Opens an image of a parking lot and a matching mask-image which represents
	 * the individual parking spots and performs an analysis in order to determine
	 * which parking spots are free and which are occupied.
	 * 
	 * The result of the analysis can be saved as a new image.
	 */
	private void runSurveillanceFrameanalysis() {
		
		String filename = FileChooser.getOpenFilePath(null);

		File f = null;
		if (filename != null) {
			
			f = new File(filename);

			String maskPath = FileChooser.getOpenFilePath(null);
			File m = null;
			if (maskPath != null) {
				
				m = new File(maskPath);

				try {

					BufferedImage image = ImageIO.read(f);
					BufferedImage maskImage = ImageIO.read(m);
					
					long time = System.currentTimeMillis();
					
					maskImage = ImageProcessor.rescaleImage(maskImage, this.width, this.height, true);
					boolean[][] mask = ImageProcessor.createMask(maskImage);

					image = ImageProcessor
					        .cannyEdgeDetection(
					                ImageProcessor.gausianBlur(
					                        ImageProcessor.convertToGrayScale(
					                                ImageProcessor.rescaleImage(
					                                        image, this.width, this.height,
					                                        true)),
					                        6, 0.7, cornerPolicy.weight, mask).blur(),
					                170, 200, mask);

					boolean[][] edges = ImageProcessor.convertToBooleanArray(image);
					edges = ImageProcessor.combineEdges(
					        ImageProcessor.filterForEdges(edges, mask, 4, true),
					        ImageProcessor.filterForEdges(edges, mask, 4, false),
					        false);
					image = ImageProcessor.convertArrayToImage(edges);
					
					System.out.println("Runtime: " + (System.currentTimeMillis() - time));
					
					String output = FileChooser.getSaveFilePath(null);

					if (output != null) {
						
						File outfile = new File(output);
						ImageIO.write(image, "png", outfile);
					}
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
	}
}
