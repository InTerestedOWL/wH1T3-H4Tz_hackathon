<x-guest-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard - Parkplätze') }}
        </h2>
    </x-slot>

    <div class="py-4 sm:py-8">
        <div class="flex flex-col max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-rows-3 sm:grid-rows-1 sm:grid-cols-3 gap-4 mb-6 p-4">
                <div class="w-full bg-white overflow-hidden shadow-xl rounded-xl h-full">
                    <div class="flex flex-col px-4 py-10 text-center justify-center">
                        <div class="text-xl font-semibold">
                            Parkplätze gesamt
                        </div>

                        <div class="text-4xl text-blue-600 mt-4 font-semibold">
                            {{ $amountParkingSpots }}
                        </div>
                    </div>
                </div>

                <div class="w-full bg-white overflow-hidden shadow-xl rounded-xl h-full">
                    <div class="flex flex-col px-4 py-10 text-center justify-center">
                        <div class="text-xl font-semibold">
                            freie Parkplätze
                        </div>

                        <div class="text-4xl text-green-600 mt-4 font-semibold">
                            {{ $freeParkingSpots }}
                        </div>
                    </div>
                </div>

                <div class="w-full bg-white overflow-hidden shadow-xl rounded-xl h-full">
                    <div class="flex flex-col px-4 py-10 text-center justify-center">
                        <div class="text-xl font-semibold">
                            besetzte Parkplätze
                        </div>

                        <div class="text-4xl text-red-600 mt-4 font-semibold">
                            {{ $usedParkingSpots }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-4 mb-6">
                <div class="bg-white overflow-hidden shadow-xl rounded-xl h-full pb-8 sm:pt-4">
                    <div class="relative px-6 pt-1">
                        <div class="flex mb-2 items-center justify-between">
                            <div>
                              <span
                                  class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full @if($perCentUsed < 40) text-green-600 bg-green-200 @elseif($perCentUsed >= 40 && $perCentUsed <=70) text-yellow-600 bg-yellow-200 @else text-red-600 bg-red-200 @endif">
                                belegte Parkplätze
                              </span>
                            </div>
                            <div class="text-right">
                              <span class="text-xs font-semibold inline-block @if($perCentUsed < 40) text-green-600 @elseif($perCentUsed >= 40 && $perCentUsed <=70) text-yellow-600 @else text-red-600 @endif">
                                {{ $perCentUsed . '%' }}
                              </span>
                            </div>
                        </div>
                        <div class="overflow-hidden h-2 mb-4 text-xs flex rounded @if($perCentUsed < 30) bg-green-200 @elseif($perCentUsed >= 40 && $perCentUsed <=70) bg-yellow-200 @else bg-red-200 @endif">
                            <div style="width: {{ $perCentUsed }}%"
                                 class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center @if($perCentUsed < 40) bg-green-500 @elseif($perCentUsed >= 40 && $perCentUsed <=70) bg-yellow-500 @else bg-red-500 @endif"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-4">
                <div class="bg-white overflow-hidden shadow-xl rounded-xl h-full pb-8 sm:pt-4">
                    <div class="flex mx-4 py-4 justify-center text-2xl font-semibold">
                        visueller Parkplatz
                    </div>

                    <div class="flex flex-col pt-2 mx-4">
                        @foreach($parkingSpots as $spotRow)
                            <div class="flex flex-row">
                                @foreach($spotRow as $spot)
                                    @foreach($spot as $spotItem)
                                        @if($spotItem)
                                            <div style="width: calc(100% / {{ $maxWidthSpots }});"
                                                 class="@if($maxWidthSpots > 10) m-0.5 @else m-2 @endif h-12 sm:h-48 rounded-2xl bg-green-600 bg-opacity-75 border-4 border-green-700">
                                            </div>
                                        @else
                                            <div style="width: calc(100% / {{ $maxWidthSpots }});"
                                                 class="m-2 h-12 sm:h-48 rounded-2xl bg-red-600 bg-opacity-75 border-4 border-red-700">
                                            </div>
                                        @endif
                                    @endforeach
                                @endforeach

                                @if(($maxWidthSpots) > count($spotRow))
                                    <div style="width: calc(100% / {{ $maxWidthSpots }});"
                                         class="m-2 h-12 sm:h-48 rounded-2xl bg-transparent border-4 border-transparent">
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>

                    <div class="flex mx-4 py-4 justify-center text-2xl font-semibold mt-10">
                        mögliche Klassifizierung mittels eines Bildes
                    </div>

                    <div class="flex flex-col pt-2 mx-4">
                        <img src="{{ mix('images/Hackathon_Bild.png') }}" alt="Demo Bild">
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-guest-layout>
