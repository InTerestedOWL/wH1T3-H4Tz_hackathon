<?php

namespace App\Http\Livewire;

use Livewire\Component;

class LoRaWan extends Component
{
    public $amountParkingSpots = 0;
    public $freeParkingSpots = 0;
    public $usedParkingSpots = 0;


    public array $parkingSpots;
    public $maxWidthSpots = 0;
    public $perCentUsed = 0;

    public function render()
    {
        return view('livewire.lo-ra-wan');
    }

    public function mount()
    {

        // true => free
        // false => used
        $this->parkingSpots = array(
            array(
                array(
                    'status' => false
                ),
                array(
                    'status' => false
                ),
                array(
                    'status' => true
                ),
                array(
                    'status' => true
                ),
            ),
            array(
                array(
                    'status' => true
                ),
                array(
                    'status' => false
                ),
                array(
                    'status' => true
                ),
            )
        );

        foreach ($this->parkingSpots as $rowValue) {
            if (count($rowValue) > $this->maxWidthSpots) {
                $this->maxWidthSpots = count($rowValue);
            }

            foreach ($rowValue as $colValue) {

                if ($colValue['status']) {
                    $this->freeParkingSpots++;
                } else {
                    $this->usedParkingSpots++;
                }
            }
        }

        $this->amountParkingSpots = $this->freeParkingSpots + $this->usedParkingSpots;


        $this->perCentUsed = round(($this->usedParkingSpots / $this->amountParkingSpots) * 100);
    }
}
