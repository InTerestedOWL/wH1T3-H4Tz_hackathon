#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <time.h>
#include <string.h>

// Ports fuer Services ECHO und DAYTIME
#define SERVER_ECHO     4707
#define SERVER_TIME     4713

// main
int main(int argc, char **argv) {
    int server_echo, server_time;                 // Serversockets
    int client_fd;                                // Clientsocket
    struct sockaddr_in server_addr, client_addr;  // Server- und Clientadresse
    fd_set server_fds;                            // Filedescriptorset
    time_t mytime;                                // Zeitvariablen
    struct tm *mytm;
    char buffer[512];                             // Ein-/Ausgabepuffer
    socklen_t client_len;
    int nbytes, rval, length;

    // Server Sockets anlegen und oeffnen
    // Familie: Internet, Typ: TCP-Socket
    server_echo = socket(AF_INET, SOCK_STREAM, 0);
    fprintf(stderr, "socket: echo %d\n", server_echo);
    if (server_echo < 0) {
        perror("socket");
        return 1;
    }
    server_time = socket(AF_INET, SOCK_STREAM, 0);
    fprintf(stderr, "socket: time %d\n", server_time);
    if (server_time < 0) {
        perror("socket");
        return 1;
    }

    // Serverstrukturen einrichten
    // Datenstruktur auf 0 setzen
    // Familie: Internetserver
    // Adresse: beliebige Clientadressen zulassen
    // Ports fuer ECHO und DAYTIME
    memset((void *) &server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(SERVER_ECHO);
    bind(server_echo, (struct sockaddr *) &server_addr, sizeof(server_addr));
    memset((void *) &server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(SERVER_TIME);
    bind(server_time, (struct sockaddr *) &server_addr, sizeof(server_addr));

    // Empfangsbereitschaft herstellen und auf Verbindung warten
    fprintf(stderr, "listen\n");
    listen(server_echo, 5);
    listen(server_time, 5);

    // Server laeuft in Endlosschleife
    while (1) {

        // Sockets in Datenstruktur fuer select() eintragen
        FD_ZERO(&server_fds);
        FD_SET(server_echo, &server_fds);
        FD_SET(server_time, &server_fds);
        // Auf Verbindung an den Sockets warten
        fprintf(stderr, "select: ...");
        select(server_time + 4, &server_fds, NULL, NULL, NULL);
        fprintf(stderr, "...\n");

        // ECHO-Service bedienen:
        // Verbindung annehmen, Nachricht lesen und zurueckschicken
        if (FD_ISSET(server_echo, &server_fds)) {
            fprintf(stderr, "accept echo ... ");
            client_len = sizeof(client_addr);
            client_fd = accept(server_echo, (struct sockaddr *) &client_addr, &client_len);
            fprintf(stderr, "\nclient: %d\n", client_fd);
            if (client_fd < 0) {
                perror("accept");
                continue;
            }
            // Echo: Nachricht von Client lesen
            fprintf(stderr, "# echo start ---------------------------------\n");
            nbytes = read(client_fd, buffer, sizeof(buffer) - 1);
            if (nbytes == 0) {
                perror("write - eof");
                close(client_fd);
                continue;
            }
            buffer[nbytes] = '\0';
            fprintf(stderr, "read: %d - %s", nbytes, buffer);
            // Nachricht zurueckschicken
            length = strlen(buffer);
            nbytes = write(client_fd, buffer, nbytes);
            fprintf(stderr, "write: %d bytes - %s", nbytes, buffer);
            if (nbytes != length) {
                perror("write");
            }
            fprintf(stderr, "# echo ende ----------------------------------\n");
        }

        // DAYTIME-Service bedienen:
        // Verbindung annehmen, Server-Datum und -Uhrzeit senden
        if (FD_ISSET(server_time, &server_fds)) {
            fprintf(stderr, "accept time ... ");
            client_len = sizeof(client_addr);
            client_fd = accept(server_time, (struct sockaddr *) &client_addr, &client_len);
            fprintf(stderr, "\nclient: %d\n", client_fd);
            if (client_fd < 0) {
                perror("accept");
                continue;
            }
            // Nachricht mit Datum und Uhrzeit erstellen und senden
            mytime = time(NULL);
            mytm = localtime(&mytime);
            fprintf(stderr, "# time start ---------------------------------\n");
            sprintf(buffer, "%02d.%02d.%04d %02d:%02d:%02d\n",
                    mytm->tm_mday, mytm->tm_mon + 1, mytm->tm_year + 1900,
                    mytm->tm_hour, mytm->tm_min, mytm->tm_sec);
            length = strlen(buffer);
            nbytes = write(client_fd, buffer, length);
            fprintf(stderr, "write: %d bytes - %s", nbytes, buffer);
            if (nbytes != length) {
                perror("write");
            }
            fprintf(stderr, "# time ende ----------------------------------\n");
        }

        // Verbindung zum Client schliessen und Ende
        fprintf(stderr, "close\n");
        close(client_fd);
    }

    return 0;
}