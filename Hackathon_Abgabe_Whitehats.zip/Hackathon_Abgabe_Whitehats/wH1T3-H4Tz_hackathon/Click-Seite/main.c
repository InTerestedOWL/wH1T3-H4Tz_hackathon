#include "httpd.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

char *def_username;
char *def_password;

FILE * fp;
struct stat filestat;
int fd;
char filesize[7];
char file_buf[1024] = {0};

int main(int c, char **v) {
    serve_forever("1337");
    return 0;
}

void route() {
    ROUTE_START()

    ROUTE_GET("/"){
            printf("HTTP/1.1 200 OK\r\n\r\n");
            printf("<!DOCTYPE html><html lang=\"en\"><head>    <meta charset=\"UTF-8\">    <title>UI</title>    <style>        body {            background-color: whitesmoke;            opacity: 0.9;        }        span {        }        .container {            position: relative;            width: 100%;        }        .nav {            display: flex;            flex-direction: row;            width: 100%;            justify-content: center;        }        .button {            background-color: coral;            margin-left: 0.5rem;            margin-right: 0.5rem;            vertical-align: middle;            border-radius: 3px 15px 5px 30px;            text-align: center;            float: left;            padding: 20px;        }        .text {            background-color: black;            vertical-align: middle;            margin-left: 2rem;            margin-right: 2rem;            vertical-align: middle;            border-radius: 3px 15px 5px 30px;            text-align: center;            float: left;            padding: 20px;        }        .frontButton {            float: left;            width: 200px;            background-color: yellowgreen;        }        .backButton {            float: right;            width: 200px;            background-color: blueviolet;        }        #top {            position: relative;            height: 75vh;        }        #bild {            display: flex;            align-items: center;            justify-content: center;            margin-left: 40%;            position: absolute;        }        #canvas {            border: antiquewhite;        }        #img {            width: 100%;            visibility: hidden;            height: 75vh;            object-fit: contain;            object-position: center;        }        #new {            background-color: darkgrey;        }        #delete {            background-color: coral;        }        #parkplaetze {            background-color: burlywood;            margin-left: 20px;            vertical-align: center;        }        #text {            background-color: burlywood;        }        #send {            background-color: coral;        }    </style>    <script>        window.addEventListener(\"load\", function () {            let canvas = document.getElementById('canvas')            let park = document.getElementById('canvas')            let img = document.getElementById('img')            let parkplatz = document.getElementById('new')            let del = document.getElementById('delete')            let send = document.getElementById('send')            canvas.width = img.clientWidth;            canvas.height = img.clientHeight;            park.width = img.clientWidth;            park.height = img.clientHeight;            let space = park.getContext('2d'); //Parkplatz            let imgObj = new Image();            let anzahlparkplatz = new Array();            let polygon = new Array();            if (!polygon) polygon = [];            canvas.addEventListener('click', function (event) {                console.log(\"Mouse Klick\");                let mousePos = getMousePos(canvas, event);                console.log(polygon);                if (polygon.length == 0) {                    space.moveTo(mousePos.x, mousePos.y);                }                if (polygon.length > 0) {                    space.lineTo(mousePos.x, mousePos.y);                    space.stroke();                }                space.fillRect(mousePos.x, mousePos.y, 5, 5);                polygon.push(mousePos);                        });            parkplatz.addEventListener('click', function (event) {                if (polygon.length >= 4) {                    space.lineTo(polygon[0].x, polygon[0].y);                    space.fillStyle = \"#ff0000\";                    space.stroke();                    space.fill();                    space.fillRect(polygon[0].x, polygon[0].y, 5, 5);                    anzahlparkplatz.push(polygon);                    console.log(anzahlparkplatz);                    polygon = [];                    document.getElementById(\"parkplaetze\").innerHTML = anzahlparkplatz.length;                }            });            imgObj.onload = function () {                let w = canvas.width;                let nw = imgObj.naturalWidth;                let nh = imgObj.naturalHeight;                let aspect = nw / nh;                let h = w / aspect;                canvas.height = h;                space.drawImage(imgObj, 0, 0, imgObj.width / 2, imgObj.height / 2)            }            imgObj.src = \"./bild.jpg\";            senden(send, polygon, space, anzahlparkplatz);            del.addEventListener('click', function (event) {                space.clearRect(0, 0, canvas.width, canvas.height);                space.drawImage(imgObj, 0, 0, imgObj.width / 2, imgObj.height / 2)                space.beginPath();                polygon.pop();                if (polygon.length > 0) {                    generatepolygon(polygon, space);                    if (anzahlparkplatz.length > 0) {                        generateparkingslot(anzahlparkplatz, space)                    }                } else {                    polygon = nextparkingslot(anzahlparkplatz);                    document.getElementById(\"parkplaetze\").innerHTML = anzahlparkplatz.length;                    generatepolygon(polygon, space);                    generateparkingslot(anzahlparkplatz, space)                }            })        })        function nextparkingslot(anzahlparkplatz) {            let count = anzahlparkplatz.pop();            return count        }        function generatepolygon(polygon, space) {            space.fillRect(polygon[0].x, polygon[0].y, 5, 5);            space.moveTo(polygon[0].x, polygon[0].y);            for (let a = 1; a < polygon.length; a++) {                space.lineTo(polygon[a].x, polygon[a].y);                space.fillRect(polygon[a].x, polygon[a].y, 5, 5);            }            space.stroke();        }        function generateparkingslot(parkingslot, space) {                        for (let a = 0; a < parkingslot.length; a++) {                generatepolygon(parkingslot[a], space)                space.lineTo(parkingslot[a][0].x, parkingslot[a][0].y);                space.fill();            }            space.stroke();        }        function senden(send, polygon, space, anzahlparkplatz) {            send.addEventListener('click', function (event) {                            });        }        function safe(parkplatz, polygon, space, anzahlparkplatz) {            parkplatz.addEventListener('click', function (event) {                if (polygon.length >= 4) {                    space.lineTo(polygon[0].x, polygon[0].y);                    space.stroke();                    anzahlparkplatz.push(polygon);                    console.log(anzahlparkplatz);                    polygon = [];                }            });            return anzahlparkplatz;        }        function getMousePos(canvas, evt) {            let rect = canvas.getBoundingClientRect();            return {                x: evt.clientX - rect.left,                y: evt.clientY - rect.top            };        }    </script></head><body><div class=\"container\">    <div id=\"top\">        <div id=\"bild\">            <canvas id=\"canvas\"></canvas>            <img src=\"bild.jpg\" id=\"img\" alt=\"Parkplatz\">        </div>    </div>    <div class=\"nav\">        <div class=\"button\" id=\"new\"> Neuer Parkplatz</div>        <div class=\"button\" id=\"delete\">Rueckgaenig</div>        <div class=\"button\" id=\"send\">Senden</div>        <div class=\"button\" id=\"text\">Anzahl Parkplaetze<span id=\"parkplaetze\"></span></div>    </div></div></body></html>");
        }

    ROUTE_GET("/bild.jpg"){
            printf("HTTP/1.1 200 OK\r\n\r\n");
            if ( ((fd = open("./bild.jpg", 'r')) < -1) || (fstat(fd, &filestat) < 0) ) {
                perror ("Error in measuring the size of the file");
            }

            sprintf (filesize, "%zd", filestat.st_size);
            //perror("File size %s\n");

            fp = fopen ("./bild.jpg", "r");
            if (fp == NULL)
            {
                perror("fopen error");
                exit(1);
            }

            fread(file_buf, sizeof(char), filestat.st_size + 1, fp);
            perror("fp closed");
            fclose(fp);
            perror("Please confirm");
            printf(file_buf);
    }

    ROUTE_POST("/")
        {
            printf("HTTP/1.1 200 OK\r\n\r\n");
            printf("Wow, seems that you POSTed %d bytes. \r\n", payload_size);
            printf("Fetch the data using `payload` variable.");
        }

        ROUTE_END()
}

bool checklogin(char *username, char *password) {
    if (strcmp(username, def_username) && strcmp(password, def_password)) {
        return true;
    }

    return false;
}
